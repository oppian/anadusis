from django.contrib import admin
from voting.models import Vote

admin.site.register(Vote)
