# -*- coding: utf-8 -*-

__about__ = """
This project comes with the bare minimum set of applications and templates
to get you started. It includes no extra tabs, only the profile and notices
tabs are included by default. From here you can add any extra functionality
and applications that you would like.
"""
