# -*- coding: utf-8 -*-

__about__ = """
This project demonstrates a social networking site. It provides profiles,
friends, photos, blogs, tribes, wikis, tweets, bookmarks, swaps,
locations and user-to-user messaging.

In 0.5 this was called "complete_project".
"""
