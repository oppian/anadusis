# -*- coding: utf-8 -*-

__about__ = """
A very simple CMS that lets you set up templates and then edit content,
including images, right in the frontend of the site.

The sample media, templates and content including in the project demonstrate
a basic company website.
"""
