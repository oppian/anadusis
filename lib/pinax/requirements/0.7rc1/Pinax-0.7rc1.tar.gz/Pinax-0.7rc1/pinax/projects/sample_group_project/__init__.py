# -*- coding: utf-8 -*-

__about__ = """
This project demonstrates group functionality with a barebones group
containing no extra content apps as well as two additional group types,
tribes and projects, which show different membership approaches and
content apps.
"""
