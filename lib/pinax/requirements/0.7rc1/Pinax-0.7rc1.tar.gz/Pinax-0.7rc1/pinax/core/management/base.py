class BaseCommand(object):
    pass